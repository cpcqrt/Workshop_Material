import ScriptEnv
ScriptEnv.Initialize("Ansoft.ElectronicsDesktop")
oDesktop.RestoreWindow()
oProject = oDesktop.GetActiveProject()
oDesign = oProject.GetActiveDesign()
name=oProject.GetName()
oDesign.ExportNetworkData("", ["HFSS Setup 1:Sweep1"], 3, "{}.snp".format(name), [0, 50000000, 100000000, 150000000, 200000000, 250000000, 300000000, 350000000, 400000000, 450000000, 500000000, 550000000, 600000000, 650000000, 700000000, 750000000, 800000000, 850000000, 900000000, 950000000, 1000000000], True, 50, "S", -1, 0, 15, True, True, False)
